package utils;

import model.Movie;

@SuppressWarnings("ALL")
public interface MovieClickListener {
    void onMovieClick(Movie movie);

}